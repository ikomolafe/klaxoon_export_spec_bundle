#!/usr/bin/env sh
set -eu

BUNDLE_ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
UNAME=$(uname -s)

if [ -n "${KD_INSTALL_ROOT:-}" ]; then
  INSTALL_ROOT="$KD_INSTALL_ROOT"
else
  case "$UNAME" in
    Darwin)
      INSTALL_ROOT="${HOME}/Library/Application Support/KlaxoonBulkExport/macos-arm64"
      ;;
    Linux)
      INSTALL_ROOT="${HOME}/.local/share/klaxoon-bulk-export/macos-arm64"
      ;;
    *)
      echo "Unsupported OS: $UNAME" >&2
      exit 1
      ;;
  esac
fi

EXTENSION_TARGET="$INSTALL_ROOT/browser-extension"
HELPER_TARGET="$INSTALL_ROOT/native-helper"
HELPER_EXE="$HELPER_TARGET/Klaxoon.NativeHelper"

mkdir -p "$EXTENSION_TARGET" "$HELPER_TARGET"
cp -R "$BUNDLE_ROOT/browser-extension/." "$EXTENSION_TARGET/"
cp -R "$BUNDLE_ROOT/native-helper/." "$HELPER_TARGET/"
chmod +x "$HELPER_EXE"

write_manifest() {
  BROWSER_ID="$1"
  HOST_DIR="$2"
  if [ -n "${KD_NATIVE_HOST_ROOT:-}" ]; then
    HOST_DIR="$KD_NATIVE_HOST_ROOT/$BROWSER_ID"
  fi
  MANIFEST_TARGET="$HOST_DIR/com.company.klaxoon_export.json"
  mkdir -p "$HOST_DIR"
  sed "s|__HELPER_PATH__|$HELPER_EXE|g" "$BUNDLE_ROOT/manifest-template.json" > "$MANIFEST_TARGET"
}

case "$UNAME" in
  Darwin)
    write_manifest "chrome" "${HOME}/Library/Application Support/Google/Chrome/NativeMessagingHosts"
    write_manifest "edge" "${HOME}/Library/Application Support/Microsoft Edge/NativeMessagingHosts"
    write_manifest "brave" "${HOME}/Library/Application Support/BraveSoftware/Brave-Browser/NativeMessagingHosts"
    write_manifest "chromium" "${HOME}/Library/Application Support/Chromium/NativeMessagingHosts"
    ;;
  Linux)
    write_manifest "chrome" "${XDG_CONFIG_HOME:-${HOME}/.config}/google-chrome/NativeMessagingHosts"
    write_manifest "edge" "${XDG_CONFIG_HOME:-${HOME}/.config}/microsoft-edge/NativeMessagingHosts"
    write_manifest "brave" "${XDG_CONFIG_HOME:-${HOME}/.config}/BraveSoftware/Brave-Browser/NativeMessagingHosts"
    write_manifest "chromium" "${XDG_CONFIG_HOME:-${HOME}/.config}/chromium/NativeMessagingHosts"
    ;;
esac

echo "Installed helper and native messaging host."
echo "Load the unpacked extension from: $EXTENSION_TARGET"
echo "Supported browsers: Google Chrome, Microsoft Edge, Brave, Chromium"
echo "Deterministic extension ID: hkkniaifdcccdnfoahdnoheieoenogoj"
